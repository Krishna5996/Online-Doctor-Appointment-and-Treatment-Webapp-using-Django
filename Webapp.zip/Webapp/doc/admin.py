from django.contrib import admin
from doc.models import *

admin.site.register(Custreg)
admin.site.register(Hosreg)
admin.site.register(Slotbook)
