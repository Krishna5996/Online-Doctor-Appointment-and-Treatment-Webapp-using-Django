from django.apps import AppConfig


class DocConfig(AppConfig):
    name = 'doc'
