from django.db import models

class Custreg(models.Model):
    cust_mail = models.CharField(max_length=20)
    cust_name = models.CharField(max_length=20)
    cust_pass = models.CharField(max_length=20)
    cust_phone = models.CharField(max_length=10)
    cust_type = models.CharField(max_length=8,default='customer')

    def __str__(self):
        return self.cust_mail

class Hosreg(models.Model):
    hos_depart = models.CharField(max_length=20,default='')
    hos_mail = models.CharField(max_length=20)
    hos_name = models.CharField(max_length=20)
    hos_pass = models.CharField(max_length=20)
    hos_type = models.CharField(max_length=10,default='hospital')
    hos_slot_cost = models.IntegerField(null=True,blank=True,default=250)

    def __str__(self):
        return self.hos_depart

class Slotbook(models.Model):
    slot_depart = models.CharField(max_length=20,default='')
    slot_doc_id = models.IntegerField(default=0)
    slot_doc_name = models.CharField(max_length=20,default='')
    slot_mail = models.CharField(max_length=20,null=True,blank=True)
    slot_date = models.DateField(null=True,blank=True)
    slot_no = models.IntegerField(null=True,blank=True,default=0)
    slot_cost = models.IntegerField(default=100,blank=True)
    slot_noti = models.TextField(null=True,blank=True,default="no")
    slot_status = models.CharField(default='no',max_length=3)

    def __str__(self):
        return self.slot_mail
