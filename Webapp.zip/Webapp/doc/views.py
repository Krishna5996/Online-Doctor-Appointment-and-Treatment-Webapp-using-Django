from django.http import HttpResponse
from django.shortcuts import redirect
from django.template import loader
from doc.models import *
from datetime import datetime, date, time

def index(request):
    template = loader.get_template('index.html')
    context = {}
    request.session.flush()

    slotobj = Slotbook.objects.all()
    pdate = (datetime.now()).date()
    ptime = (datetime.now()).time()

    for obj in slotobj:
        sdate = obj.slot_date
        if pdate == sdate:
            sh = ptime.hour
            eh = int(obj.slot_no)
            if sh >= eh + 1:
                obj.slot_status = 'de-activate'

        if pdate >= sdate:
            obj.delete()

    return HttpResponse(template.render(context,request))

def reg(request):
    template = loader.get_template('register.html')
    context = {'mess':''}

    if request.method == 'POST':

        uname = request.POST.get('uname')
        uno = request.POST.get('uno')
        umail = request.POST.get('uemail')
        upass = request.POST.get('upass')
        upass1 = request.POST.get('upass1')

        cobjs = Custreg.objects.all()

        if upass != upass1:
            context['mess'] = ' Password mismatch '

        try:
            uno == int(uno)
        except:
            context['mess'] += ' Enter Phone number correctly '

        if context['mess'] == '':
            for cobj in cobjs:
                if cobj.cust_mail == umail:
                    context['mess'] = "Email Already exist"

            if context['mess'] == '':
                cobj = Custreg.objects.create(cust_name=uname, cust_phone=uno, cust_mail=umail, cust_pass=upass)
                cobj.save()
                context['mess'] = 'Account Created successfully'

    return HttpResponse(template.render(context,request))

def login(request):
    template = loader.get_template('login.html')
    context = {}

    request.session['cmail'] = None
    request.session['olc'] = None

    if request.method == 'POST':

        umail = request.POST.get('uemail')
        upass = request.POST.get('upass')

        custobjs = Custreg.objects.all()
        hosobjs = Hosreg.objects.all()

        for cobj in custobjs:
            if cobj.cust_mail == umail and cobj.cust_pass == upass:
                request.session['cmail'] = cobj.cust_mail
                return redirect('custhome')

        for oobj in hosobjs:
            if oobj.hos_mail == umail and oobj.hos_pass == upass:
                request.session['mmail'] = oobj.hos_mail
                return redirect('hoshome')

        context['message'] = 'Email or password in-correct'

    return HttpResponse(template.render(context,request))

def logout(request):
    template = loader.get_template('logout.html')
    context = {}

    request.session['cmail'] = None
    request.session['mloc'] = None
    request.session.flush()

    return redirect('index')

def forgot(request):
    template = loader.get_template('forgot.html')
    context = {'mess': ''}

    if request.method == 'POST':
        sname = request.POST.get('uname')
        smail = request.POST.get('umail')
        spass = request.POST.get('upass')

        uobj = Custreg.objects.all()

        for x in uobj:
            if x.cust_mail == smail and x.cust_name == sname:
                x.cust_pass = spass
                x.save()
                context['mess'] = 'Successfully Password Changed'

        del uobj

        uobj = Hosreg.objects.all()

        for x in uobj:
            if context['mess'] != 'Successfully Password Changed':
                if x.hos_mail == smail and x.hos_name == sname:
                    x.hos_pass = spass
                    x.save()
                    context['mess'] = 'Successfully Password Changed'

        del uobj

        if context['mess'] != 'Successfully Password Changed':
            context['mess'] = 'username or email not found'

    return HttpResponse(template.render(context, request))

def sample(request):
    template = loader.get_template('sample.html')
    context = {'mess': ''}

    context['cobj'] = cobj = Custreg.objects.all()
    context['mobj'] = mobj = Hosreg.objects.all()
    context['sobj'] = sobj = Slotbook.objects.all()

    return HttpResponse(template.render(context, request))

# ---------- customer pages ----------------

def custhome(request):
    template = loader.get_template('cust/custhome.html')
    context = {'mess':''}

    if request.session.has_key('cmail'):
        context['cmail'] = cmail = request.session['cmail']
        context['mobj'] = mobj = Hosreg.objects.all()

        for s in Slotbook.objects.all():
            if s.slot_status == 'no':
                s.delete()

        pdate = (datetime.now()).date()
        pdate_day = pdate.day
        pdate_month = pdate.month
        pdate_year = pdate.year

        if request.method == 'POST':

            cslot = int(request.POST.get('cslot'))
            cdate = request.POST.get('cdate')
            obj = Hosreg.objects.get(id=cslot)
            format_str = '%Y-%m-%d'
            cd = datetime.strptime(cdate, format_str)
            cd_day = cd.day
            cd_month = cd.month
            cd_year = cd.year

            if cd_year >= pdate.year:
                if cd_month == pdate.month:
                    if cd_day >= pdate.day:
                        context['mess'] = ''
                    else:
                        context['mess'] = 'Enter proper Date'
                elif cd_month > pdate.month:
                    if cd_day <= pdate.day:
                        context['mess'] = ''
                    else:
                        context['mess'] = 'Enter proper Date'
                else:
                    context['mess'] = 'Enter proper Date'
            else:
                context['mess'] = 'Enter proper Date'

            if context['mess'] == '':
                sobj = Slotbook.objects.create()
                sobj.slot_depart = obj.hos_depart
                sobj.slot_doc_id = obj.id
                sobj.slot_date = cd
                sobj.slot_mail = cmail
                sobj.slot_cost = obj.hos_slot_cost
                sobj.slot_doc_name = obj.hos_name
                sobj.save()
                request.session['sid'] = sobj.id
                return redirect('custslot')

    else:
        return redirect('index')

    return HttpResponse(template.render(context, request))

def custslot(request):

    template = loader.get_template('cust/custslot.html')
    context = {'mess':'','slotno':['1','2','3','4','5','6','7','8','9','10'],'slotava':[]}
    sid = request.session['sid']
    sdata = Slotbook.objects.get(id=sid)
    context['bslot'] = bslot = Slotbook.objects.all()
    pdate = (datetime.now()).date()
    ptime = (datetime.now()).time()
    eh = 1
    for obj in bslot:
        if str(obj.slot_depart) == str(sdata.slot_depart) and str(obj.slot_date) == str(sdata.slot_date):
            context['slotava'].append(str(obj.slot_no))
            sdate = obj.slot_date

    sh = int(ptime.hour) - 6
    for x in range(1,sh+1):
        context['slotava'].append(str(x))

    print(context['slotava'])

    if request.method == 'POST':
        sradio = request.POST.get('select_radio')
        if context['mess'] == '':
            if sradio != None:
                sdata.slot_no = sradio
            sdata.save()
            return redirect('custconfirm')

    return HttpResponse(template.render(context, request))

def custconfirm(request):
    template = loader.get_template('cust/custconfirm.html')
    context = {}

    sid = request.session['sid']
    context['x'] = sobj = Slotbook.objects.get(id=sid)
    if request.method == 'POST':
        sobj.slot_status = 'no'
        sobj.save()
        return redirect('custack')

    return HttpResponse(template.render(context, request))

def custack(request):
    template = loader.get_template('cust/custack.html')
    context = {}

    sid = request.session['sid']
    context['x'] = sobj = Slotbook.objects.get(id=sid)
    sobj.slot_status = 'yes'
    sobj.save()
    request.session['sid'] = None
    del request.session['sid']
    request.session.modified = True

    return HttpResponse(template.render(context, request))

def custprofile(request):
    template = loader.get_template('cust/custprofile.html')
    context = {}
    context['custmail'] = custmail = request.session['cmail']

    cobj = Custreg.objects.get(cust_mail=custmail)
    context['cobj'] = cobj
    if request.method == "POST":
        cname = request.POST.get('cname')
        cpass = request.POST.get('cpass')
        cno = request.POST.get('cno')

        cobj.cust_pass = cpass
        cobj.cust_phone = int(cno)
        context['message'] = 'your profile has been updated'
        cobj.save()

    return HttpResponse(template.render(context, request))

def custnote(request):
    template = loader.get_template('cust/custnote.html')
    context = {'mess':'','dis':''}
    context['cmail'] = cmail = request.session['cmail']
    context['uobj'] = uobj = Custreg.objects.get(cust_mail=cmail)
    context['sobj'] = sobj = Slotbook.objects.all()

    for x in sobj:
        if x.slot_mail == uobj.cust_mail and x.slot_noti != 'no':
            context['dis'] = 'yes'
    return HttpResponse(template.render(context,request))

def custcancel(request):
    template = loader.get_template('cust/custcancel.html')
    context = {'mess':'','dis':''}

    context['cmail'] = cmail = request.session['cmail']
    context['uobj'] = uobj = Custreg.objects.get(cust_mail=cmail)
    context['sobj'] = sobj = Slotbook.objects.all()

    for x in sobj:
        if x.slot_mail == uobj.cust_mail and x.slot_status == 'yes':
            print(x.slot_mail)
            context['dis'] = 'yes'

    if request.method == 'POST':
        rval = int(request.POST.get('rval'))
        obj = Slotbook.objects.get(id=rval)
        obj.delete()
        return redirect('custcancel')

    return HttpResponse(template.render(context,request))

# ---------- hospital pages -----------------

def hoshome(request):
    template = loader.get_template('hospital/hoshome.html')
    context = {}
    mmail = request.session['mmail']
    context['hos'] = hos = Hosreg.objects.get(hos_mail=mmail)
    context['sobj'] = sobj = Slotbook.objects.all()

    for x in sobj:
        if x.slot_depart == hos.hos_depart:
            context['dis'] = 'yes'

    return HttpResponse(template.render(context, request))

def checkin(request):
    template = loader.get_template('hospital/checkin.html')
    context = {'dis': ''}

    mmail = request.session['mmail']
    context['hos'] = hos = Hosreg.objects.get(hos_mail=mmail)
    context['sobj'] = sobj = Slotbook.objects.all()

    for x in sobj:
        if x.slot_depart == hos.hos_depart:
            context['dis'] = 'yes'

    return HttpResponse(template.render(context, request))

def viewinfo(request):
    template = loader.get_template('hospital/viewinfo.html')
    context = {'dis':''}
    context['list'] = list = [1,2,3,4,5,6,7,8,9,10]
    context['list_2'] = list_2 = []

    mmail = request.session['mmail']
    context['hos'] = hos = Hosreg.objects.get(hos_mail=mmail)
    context['slots'] = sobj = Slotbook.objects.all()
    context['pdate'] = pdate = date.today()

    for x in sobj:
        if x.slot_depart == hos.hos_depart and x.slot_doc_name == hos.hos_name and pdate == x.slot_date:
            context['dis'] = 'yes'
            list_2.append(x.slot_no)

    return HttpResponse(template.render(context, request))

def hosnotify(request):
    template = loader.get_template('hospital/hosnotify.html')
    context = {'dis':''}

    mmail = request.session['mmail']
    context['hos'] = hos = Hosreg.objects.get(hos_mail=mmail)
    context['sobj'] = sobj = Slotbook.objects.all()

    for x in sobj:
        if x.slot_depart == hos.hos_depart:
            context['dis'] = 'yes'

    if request.method == 'POST':
        rval = request.POST.get('rval')
        tval = request.POST.get('tval')
        snobj = Slotbook.objects.get(id=rval)
        snobj.slot_noti = str(tval)
        snobj.save()
        context['mess'] = 'Notified Successfully'

    return HttpResponse(template.render(context, request))
