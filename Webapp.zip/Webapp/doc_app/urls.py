from django.contrib import admin
from django.urls import path
from django.conf.urls import url, include
from doc import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index,name='index'),
    path('reg/',views.reg,name='reg'),
    path('login/',views.login,name='login'),
    path('logout/',views.logout,name='logout'),
    path('forgot/',views.forgot, name='forgot'),
    path('sample/',views.sample, name='sample'),

    # ------------ customer pages ------------

    path('custhome/',views.custhome,name='custhome'),
    path('custslot/',views.custslot,name='custslot'),
    path('custconfirm/', views.custconfirm, name='custconfirm'),
    path('custprofile/',views.custprofile,name='custprofile'),
    path('custack/',views.custack,name='custack'),
    path('custnote/',views.custnote,name='custnote'),
    path('custcancel', views.custcancel, name='custcancel'),

    # ------------ hospital pages -------------

    path('hoshome/',views.hoshome,name='hoshome'),
    path('checkin/',views.checkin,name='checkin'),
    path('viewinfo/',views.viewinfo,name='viewinfo'),
    path('hosnotify/',views.hosnotify,name='hosnotify'),
]
urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_URL)
urlpatterns += static(settings.MEDIA_ROOT, document_root=settings.MEDIA_ROOT)
