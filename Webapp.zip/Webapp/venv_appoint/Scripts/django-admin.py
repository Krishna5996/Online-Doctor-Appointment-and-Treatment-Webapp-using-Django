#!Z:\projects\naresh_projects\doc_app\venv_appoint\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
